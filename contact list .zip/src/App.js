import './App.css';
import ContactApp from './Component/ContactApp';

function App() {
  return (
    <div className='app'>
      <ContactApp/>
    </div>
  );
}

export default App;
