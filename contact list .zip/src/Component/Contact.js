import { CiTrash } from "react-icons/ci";
import { BsFillPersonFill } from "react-icons/bs";
import { Link } from "react-router-dom";
import { FaEdit } from "react-icons/fa";

const Contact = ({ contact, name, email, id, deleteHandler, setContacts }) => {
  return (
    <div className="contact">
      <div className="person-icon">
        <BsFillPersonFill />
      </div>

      <Link
        to={{
          pathname: `/user/${id}`,
          state: { contact: contact },
        }}
      >
        <div className="contact-p">
          <p>
            <span className="contact-span"> name: </span> {name}
          </p>

          <p>
            <span className="contact-span">email: </span> {email}
          </p>
        </div>
      </Link>

      <div>
        <Link to={{ pathname: `/edit/${id}`, state: { contact: contact } }}>
          <button className="contact-button">
            <FaEdit />
          </button>
        </Link>

        <button onClick={deleteHandler} className="contact-button">
          <CiTrash />
        </button>
      </div>
    </div>
  );
};

export default Contact;
