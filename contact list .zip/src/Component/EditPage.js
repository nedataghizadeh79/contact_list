import axios from "axios";
import { useState } from "react";

const EditPage = (props) => {
  const [info, setInfo] = useState({
    name: props.location.state.contact.name,
    email: props.location.state.contact.email,
    id: props.location.state.contact.id,
  });

  const changeHandler = (e) => {
    setInfo({ ...info, [e.target.name]: e.target.value });
  };

  const save_handler = () => {
    const myId = props.location.state.contact.id;
    props.location.state.contact.name = info.name;
    props.location.state.contact.email = info.email;
    axios.put(`http://localhost:3001/contacts/${myId}`, info).then((res) => {
      props.location.state.setContacts(info);
    });

    props.history.push("/");
  };

  return (
    <section className="out">
      <div className="form">
        <h1 className="h1"> Edit Page</h1>
        <div className="lableAndInput">
          <label>name</label>
          <input
            type="text"
            name="name"
            value={info.name}
            onChange={changeHandler}
          />
        </div>

        <div className="lableAndInput">
          <label>email</label>
          <input
            type="email"
            name="email"
            value={info.email}
            onChange={changeHandler}
          />
        </div>
        <button onClick={save_handler} className="form-button">
          save
        </button>
      </div>
    </section>
  );
};

export default EditPage;
