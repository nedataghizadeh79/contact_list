import axios from "axios";
import { useEffect, useState } from "react";
import { Switch, Route } from "react-router-dom";
import ContactList from "./ContactList";
import EditPage from "./EditPage";
import Form from "./Form";
import UserDetail from "./UserDetail";

const ContactApp = () => {
  const [contacts, setContacts] = useState([]);

  const addContact = (contact) => {
    axios
      .post("http://localhost:3001/contacts", contact)
      .then((res) => {
        setContacts([...contacts, contact]);
      })
      .catch((err) => {});
  };

  const deleteHandler = (id) => {
    axios
      .delete(`http://localhost:3001/contacts/${id}`)
      .then((res) => {
        let filtered = contacts.filter((c) => c.id !== id);
        setContacts(filtered);
      })
      .catch((err) => {});
  };

  useEffect(() => {
    // const savedContacts = JSON.parse(localStorage.getItem("contacts"));
    // if (savedContacts) setContacts(savedContacts);
    axios
      .get("http://localhost:3001/contacts")
      .then((res) => {
        setContacts(res.data);
      })
      .catch((err) => {});
  }, []);

  //   useEffect(() => {
  //     localStorage.setItem("contacts", JSON.stringify(contacts));
  //   }, [contacts]);

  return (
    <div className="contact-app">
      <Switch>
        <Route path="/edit/:id" component={EditPage} />
        <Route path="/user/:id" component={UserDetail} />

        <Route
          path="/add"
          render={(props) => <Form addContact={addContact} {...props} />}
        />
        <Route
          path="/"
          exact
          render={(props) => (
            <ContactList
              setContacts={setContacts}
              contacts={contacts}
              deleteHandler={deleteHandler}
              {...props}
            />
          )}
        />
      </Switch>
      {/* <Form addContact={addContact} />
      <ContactList contacts={contacts} deleteHandler={deleteHandler} /> */}
    </div>
  );
};

export default ContactApp;
