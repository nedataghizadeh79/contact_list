import { useState } from "react";

const Form = ({ addContact, history }) => {
  const [info, setInfo] = useState({
    name: "",
    email: "",
    id: Math.floor(Math.random() * 100),
  });

  const changeHandler = (e) => {
    setInfo({ ...info, [e.target.name]: e.target.value });
  };

  const clickHandler = (e) => {
    e.preventDefault();
    addContact(info);
    setInfo({ name: "", email: "", id: Math.floor(Math.random() * 100) });

    history.push("/");
  };

  const cancle_button = () => {
    history.push("/");
  };

  return (
    <section className="out">
      <div className="form">
        <h1 className="h1">Form List</h1>
        <div className="lableAndInput">
          <label>name</label>
          <input
            type="text"
            name="name"
            value={info.name}
            onChange={changeHandler}
          />
        </div>

        <div className="lableAndInput">
          <label>email</label>
          <input
            type="email"
            name="email"
            value={info.email}
            onChange={changeHandler}
          />
        </div>

        <button className="form-button" type="submit" onClick={clickHandler}>
          add contact
        </button>
        <button className="form-button" onClick={cancle_button}>
          cancle
        </button>
      </div>
    </section>
  );
};

export default Form;
