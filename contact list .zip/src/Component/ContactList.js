import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Contact from "./Contact";

const ContactList = ({ contacts, deleteHandler, setContacts }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchedContacts, setSearchedContacts] = useState([]);

  const renderContact = () => {
    return searchedContacts.map((c) => {
      return (
        <Contact
          setContacts={setContacts}
          contact={c}
          name={c.name}
          key={c.id}
          email={c.email}
          id={c.id}
          deleteHandler={() => deleteHandler(c.id)}
        />
      );
    });
  };

  useEffect(() => {
    setSearchedContacts(contacts);
  }, [contacts]);

  const searchHandler = (e) => {
    setSearchTerm(e.target.value);
    const searched = e.target.value.trim();
    if (searched !== "") {
      const filtered = searchedContacts.filter((c) => {
        return c.name.toLowerCase().includes(e.target.value.toLowerCase());
      });
      console.log(filtered);
      setSearchedContacts(filtered);
    } else {
      setSearchedContacts(contacts);
    }
  };

  return (
    <div className="contactList">
      <div className="search">
        <label className="form-lable" htmlFor="form">
          search the name
        </label>
        <input
          type="text"
          id="form"
          className="form-input"
          value={searchTerm}
          onChange={searchHandler}
        />
      </div>

      {renderContact()}
      <br />

      <Link to="/add">
        <button className="go-next-page">Go to form page</button>
      </Link>
      <br />
      <br />
    </div>
  );
};

export default ContactList;
