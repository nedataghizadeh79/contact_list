const UserDetail = (props) => {
  return (
    <div className="out">
      <p> the name is: {props.location.state.contact.name} </p>
    </div>
  );
};

export default UserDetail;
